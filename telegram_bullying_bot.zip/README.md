# Telegram Bullying Bot

Простой анонимный бот для сбора историй о буллинге.

## Развертывание на Railway (с телефона)
1. Создай репозиторий на GitHub.
2. Залей файлы из этого архива в репозиторий.
3. В Railway нажми New Project → Deploy from GitHub.
4. Выбери этот репозиторий и добавь переменные:
   - BOT_TOKEN = токен от @BotFather
   - ADMINS = твой Telegram ID (@userinfobot)
5. Нажми Deploy — бот заработает 24/7.